  const thumbnails = document.querySelectorAll('.thumbnails img');
  const mainImage = document.querySelector('.product-images img');

  thumbnails.forEach(thumb => {
    thumb.addEventListener('click', () => {
      mainImage.src = thumb.src;
    });
  });

