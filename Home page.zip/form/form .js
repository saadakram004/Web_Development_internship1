function submitForm() {
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const message = document.getElementById('message').value.trim();
  const consent = document.getElementById('consent').checked;

  if (!name || !email || !message || !consent) {
    alert("Please fill all fields and agree to the terms.");
  } else {
    alert("Form submitted successfully!");
    // Integrate with backend or email service here if needed
  }
}