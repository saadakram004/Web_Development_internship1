const track = document.getElementById('sliderTrack');
const slides = document.querySelectorAll('.slide');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');

let currentIndex = 0;
let startX = 0;
let isDragging = false;
let autoplayInterval;

function updateSlidePosition() {
  const width = slides[0].offsetWidth;
  track.style.transition = 'transform 0.5s ease-in-out';
  track.style.transform = `translateX(-${currentIndex * width}px)`;
}

function goToNextSlide() {
  currentIndex = (currentIndex + 1) % slides.length;
  updateSlidePosition();
}

function goToPrevSlide() {
  currentIndex = (currentIndex - 1 + slides.length) % slides.length;
  updateSlidePosition();
}

prevBtn.addEventListener('click', () => {
  goToPrevSlide();
  resetAutoplay();
});

nextBtn.addEventListener('click', () => {
  goToNextSlide();
  resetAutoplay();
});

track.addEventListener('mousedown', startDrag);
track.addEventListener('touchstart', startDrag, { passive: true });

track.addEventListener('mouseup', endDrag);
track.addEventListener('touchend', endDrag);

track.addEventListener('mousemove', drag);
track.addEventListener('touchmove', drag, { passive: false });

function getX(e) {
  return e.type.includes('mouse') ? e.pageX : e.touches[0].clientX;
}

function startDrag(e) {
  isDragging = true;
  startX = getX(e);
  track.style.transition = 'none';
  clearInterval(autoplayInterval);
}

function drag(e) {
  if (!isDragging) return;
  const x = getX(e);
  const moveX = x - startX;
  const width = slides[0].offsetWidth;
  track.style.transform = `translateX(-${currentIndex * width - moveX}px)`;
}

function endDrag(e) {
  if (!isDragging) return;
  isDragging = false;
  const x = getX(e);
  const moveX = x - startX;
  const width = slides[0].offsetWidth;
  const threshold = width / 4;

  if (moveX > threshold) {
    currentIndex = Math.max(0, currentIndex - 1);
  } else if (moveX < -threshold) {
    currentIndex = Math.min(slides.length - 1, currentIndex + 1);
  }

  updateSlidePosition();
  resetAutoplay();
}

function startAutoplay() {
  autoplayInterval = setInterval(goToNextSlide, 5000);
}

function resetAutoplay() {
  clearInterval(autoplayInterval);
  startAutoplay();
}

window.addEventListener('resize', updateSlidePosition);

updateSlidePosition();
startAutoplay();
