window.addEventListener("load", () => {
  const img1 = document.getElementById("img1");
  const img2 = document.getElementById("img2");
  let showFirst = true;

  // Initial fade in
  img1.classList.add("show");
  setTimeout(() => img2.classList.add("show"), 500);

  // Image switch every 4 seconds
  setInterval(() => {
    if (showFirst) {
      img1.classList.remove("show");
      img2.classList.add("show");
    } else {
      img2.classList.remove("show");
      img1.classList.add("show");
    }
    showFirst = !showFirst;
  }, 4000);
});
